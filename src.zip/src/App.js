import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Todo from './Todo';
import TodoForm from './TodoForm';
import './styles.css';

const App = () => {
    const [todos, setTodos] = useState([]);

    // Fetch all todos
    useEffect(() => {
        axios.get('http://localhost:5000/api/todos')
            .then(res => setTodos(res.data))
            .catch(err => console.log(err));
    }, []);

    // Add a new todo
    const addTodo = (text) => {
        axios.post('http://localhost:5000/api/todos', { text })
            .then(res => setTodos([...todos, res.data]))
            .catch(err => console.log(err));
    };

    // Delete a todo
    const deleteTodo = (id) => {
        axios.delete(`http://localhost:5000/api/todos/${id}`)
            .then(() => setTodos(todos.filter(todo => todo._id !== id)))
            .catch(err => console.log(err));
    };

    // Update a todo
    const updateTodo = (id, newText) => {
        axios.put(`http://localhost:5000/api/todos/${id}`, { text: newText })
            .then(res => {
                const updatedTodos = todos.map(todo => 
                    todo._id === id ? res.data : todo
                );
                setTodos(updatedTodos);
            })
            .catch(err => console.log(err));
    };

    return (
        <div className="app">
            <h1>To-Do List</h1>
            <TodoForm addTodo={addTodo} />
            {todos.map(todo => (
                <Todo key={todo._id} todo={todo} deleteTodo={deleteTodo} updateTodo={updateTodo} />
            ))}
        </div>
    );
};

export default App;
